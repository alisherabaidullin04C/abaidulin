<html>
	<head>
		<link rel="shortcut icon" href="img/значок-качества-пищи-ресторана-33714973.jpg" type="image/png">
		<meta charset="UTF-8">
		<title>Регистрация</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
				<center>
					<br>
					<br>
					<?php
						
					?>
					<form method="POST" action="reg.php">
					<a id="cuh">Информация об учетной записи</a>
					<br><br>
					<h1 id="cu">ЛОГИН:</h1>
					<input type="text" placeholder="login" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;" id='login' name='login'></input>
					<br>
					<h1 id="cu">Пароль:</h1>
					<input type="password" placeholder="password" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;" id='password' name='password'></input>
					<br>
					<h1 id="cu">Подтверждение пароля:</h1>
					<input type="password" placeholder="password" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;" id='password1' name='password1'></input>
					<br><br>
					
					<br>
					<br>
					<a id="cuh"></a>
					<br><br>
					<h1 id="cu">Имя:</h1>
					<input placeholder="name" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;" id='name' name='name'></input>
					<br>
					<br>
					<h1 id="cu">Телефон:</h1>
					<input placeholder="phone number" style="height:35px;width:200px;border-radius: 10px 10px 10px 10px;" id='phone' name='phone'></input>
					
					<div><input type="submit" value="регистрация" style="height:35px;width:85px;border-radius:10px 10px 10px 10px;margin-top:15px;margin-bottom:50px;"></input></div>
					</form>
					<br><br>
				</center>
			</div>
			<div id="las">
			
			</div>
	</center>
	</body>
</html>