<?php
	include 'connection.php';
	$log=$_POST['login'];
	$pas=$_POST['password'];
	if($log=='' || $pas==''){
		header("Location:vhod.php");
	}
	else{
		$query="SELECT * FROM users WHERE LOGIN='".$log."' AND PASSWORD='".$pas."'";
		$result=mysql_query($query);
		$a=mysql_fetch_array($result);
		if($a[1]==''){
			header("Location:vhod.php");
		}
		else{
			session_start();
			$_SESSION['login']=$log;
			header("Location:index.php");
		}
	}
?>