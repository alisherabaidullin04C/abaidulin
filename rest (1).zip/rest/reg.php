<?php
	include 'connection.php';
	$error=0;
	$log=$_POST['login'];
	$pas=$_POST['password'];
	$pas1=$_POST['password1'];
	$name=$_POST['name'];
	$phone=$_POST['phone'];
	if($log=='' || $pas=='' || $pas1=='' || $name=='' || $age=='' || $phone=='' || $pas!=$pas1){
		$error=1;
		header("Location:regis.php");
	}
	else{
		$query="INSERT INTO `users`(`LOGIN`,`PASSWORD`,`NAME`,`PHONE`) VALUES ('".$log."','".$pas."','".$name."','".$phone."')";
		$res=mysql_query($query);
	}
?>