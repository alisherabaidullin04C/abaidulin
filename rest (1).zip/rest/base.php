<?php
session_start();
?>

<div id="upe">
				<div class="im">
					<img src="img/значок-качества-пищи-ресторана-33714973.jpg" width="70" height="70"/>
				</div>
				<div class="ima">
					<a href="index.php">Best-choice</a>
				</div>
				<!-- <input type="search" name="q" placeholder="Поиск" id="sear"></input> -->
				<ul class="upen">
					<?php
						if(isset($_SESSION['login'])){
							if($_SESSION['login']!=''){
							echo '<li><a href="sclose.php"><b>LOG OUT</b></a></li>';
							echo '<li><a href="profile.php"><b>PROFILE</b></a></li>';
							}
							else{
								echo '<li><a href="regis.php"><b>SIGN IN</b></a></li>
					<li><a href="vhod.php"><b>LOG IN</b></a></li>';
							}
						}
						else{
							echo '<li><a href="regis.php"><b>SIGN IN</b></a></li>
					<li><a href="vhod.php"><b>LOG IN</b></a></li>';
						
						}
					?>
					<li><a href="cont.php"><b>CONTACTS</b></a></li>
				</ul>
</div>
 <div id="upe">
 <table>
						<tr>
							<img src="img/tumblr_nmygzzqVs11qbmm1co1_250.gif" width="50" height="50"/>
							<a class="tab" href="pizza.php">Pizza</a>
							<img src="img//tumblr_nmygzzqVs11qbmm1co1_250.gif" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/images.jpe" width="50" height="50"/>
							<a class="tab" href="sushi.php">
								Sushi
							</a>
							<img src="img/images.jpe" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/cupcake46.png" width="50" height="50"/>
							<a class="tab" href="des.php">Dessert</a>
							<img src="img/cupcake46.png" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/glass-of-water.svg" width="50" height="50"/>
							<a class="tab" href="drinks.php">Drinks</a>
							<img src="img/glass-of-water.svg" width="50" height="50"/>
						</tr>
						<tr>
							<img src="img/food-icon-meat.gif" width="50" height="50"/>
							<a class="tab" href="dishes.php">Dishes</a>
							<img src="img/food-icon-meat.gif" width="50" height="50"/>
						</tr>
	</table>
 </div>
<?php
	function prod(){
		include 'connection.php';
		if(isset($_SESSION['products'])){
			$aa=$_SESSION['products'];

			if($aa!=''){	
			foreach($aa as $v){
			$query = "SELECT * FROM prod WHERE ID='".$v."'";
			$result=mysql_query($query);
			while($row= mysql_fetch_assoc($result)){
				echo "<div class='rev'>";
				echo '<b style="float:left;color:red;margin-left:3px;margin-top:3px;">';
				echo $row['PRICE']." tg</b>";
				echo '<a href="?id='.$row['ID'].'" align="center"><img src="img/checkout-dark.png" width="20" height="20"/></a><br>';
				echo '<img src="'.$row['IMG'].'" width="150" height="145"/><br>';
				echo '<a>'.$row['NAME'].'</a><br>
							<a>'.$row['INFO'].'</a>';
				echo "</div>";

		}
		}}}
	}
	function tt($t){
		include 'connection.php';
		$query = "SELECT * FROM prod WHERE TYPE='".$t."'";
		$result=mysql_query($query);
		while($row= mysql_fetch_assoc($result)){
		echo "<div class='rev'>";
		echo '<b style="float:left;color:red;margin-left:3px;margin-top:3px;">';
		echo $row['PRICE']." tg</b>";
		echo '<a href="?id='.$row['ID'].'" align="center"><img src="img/checkout-dark.png" width="20" height="20"/></a><br>';
		echo '<img src="'.$row['IMG'].'" width="150" height="145"/><br>';
		echo '<a>'.$row['NAME'].'</a><br>
					<a>'.$row['INFO'].'</a>';
		echo "</div>";
		if(isset($_SESSION['login']))
		if($_SESSION['login']!=''){
			if(isset($_GET['id'])){
				if(isset($_SESSION['products'][0])){
				array_push($_SESSION['products'],$_GET['id']);}
				else{
					$_SESSION['products']=array($_GET['id']);
					$c=$_GET['id'];
				}
			}
		}
	}
	}
?>