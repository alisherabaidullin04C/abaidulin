-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Май 21 2016 г., 08:35
-- Версия сервера: 10.0.17-MariaDB
-- Версия PHP: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `rest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `buys`
--

CREATE TABLE `buys` (
  `LOGIN` varchar(50) NOT NULL,
  `BUYS` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `buys`
--

INSERT INTO `buys` (`LOGIN`, `BUYS`) VALUES
('qwe', ' 1 1 2'),
('qwe', ' 3 3 3 9 9 9'),
('qwe', ' 7 7 7 7'),
('qwe', ' 1 7'),
('qwe', ' 4 4'),
('qwe', ' 1 4 2 11'),
('qwe', ' 1 2');

-- --------------------------------------------------------

--
-- Структура таблицы `prod`
--

CREATE TABLE `prod` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(150) NOT NULL,
  `PRICE` int(11) NOT NULL,
  `INFO` varchar(150) DEFAULT NULL,
  `IMG` varchar(100) NOT NULL,
  `TYPE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `prod`
--

INSERT INTO `prod` (`ID`, `NAME`, `PRICE`, `INFO`, `IMG`, `TYPE`) VALUES
(1, 'Margarita', 2000, 'Cheese', 'img/mar.jpe', 'pizza'),
(2, 'Picle sushi', 699, 'picle', 'img/13935191211.jpg', 'sushi'),
(3, 'pizza with cheese', 3000, 'pizza with cheese and picles,spicy chili sause', 'img/show_image_in_imgtag (3).jpe', 'pizza'),
(4, 'pizza with mushrooms', 2500, 'pizza including fresh mushrooms.Very tasty.', 'img/show_image_in_imgtag (5).jpe', 'pizza'),
(5, 'Kyoto rolls', 500, 'Best fish products are used to prepare you this fantastic sushi.', 'img/13935177961.jpg', 'sushi'),
(6, 'Jayoko rolls', 600, 'Best fish products are used to prepare you this fantastic sushi.', 'img/13725800551.jpg', 'sushi'),
(7, 'Suabu rolls', 499, 'Best fish products are used to prepare you this fantastic sushi.', 'img/14470892651.jpg', 'sushi'),
(8, 'Napoleon', 2700, 'The most sweet pastas in Kazakhstan.', 'img/14499872501.jpg', 'des'),
(9, 'La-chesckae', 999, '"This is a very creamy cheesecake. It''s delicious plain, or you may top with fruit pie filling."', 'img/14496588201.jpg', 'des'),
(10, 'Cheeeeeeescake', 1500, '"This is a very creamy cheesecake. It''s delicious plain, or you may top with fruit pie filling."', 'img/14496603631.jpg', 'des'),
(11, 'Coca-cola', 399, 'Cold coca-cola with ice.', 'img/13725900811.jpg', 'drinks'),
(12, 'Tea', 200, 'Cold tea "LIMTON"', 'img/13725902171.jpg', 'drinks'),
(13, 'Water', 100, 'Bon-aqua,mineralized water.', 'img/13725899131.jpg', 'drinks'),
(14, 'Fish with vegetables', 2500, '"Creamy, rich, nutty, butterscotch flavor. To serve, put a dollop of sweetened whipped cream on each slice.', 'img/show_image_in_imgtag (9).jpe', 'dishes'),
(15, 'CEASER', 5000, '"Chocolate-y goodness in a cheesecake is what you get from this recipe using cocoa and chcoolate chips with the cream cheese standard."', 'img/show_image_in_imgtag (11).jpe', 'dishes'),
(16, 'Assorti with cheese', 3500, '"Creamy and chocolaty. You don''t need the big spring-form pan, just a ready-made crumb crust."', 'img/show_image_in_imgtag (8).jpe', 'dishes'),
(17, 'Ananas lovers', 2700, '"A majestic orange flavored cheesecake swirled with chocolate goodness. Orange liqueur may be substituted for the orange juice in equal amounts.', 'img/show_image_in_imgtag (10).jpe', 'dishes');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `LOGIN` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `PHONE` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`ID`, `LOGIN`, `PASSWORD`, `NAME`, `PHONE`) VALUES
(1, 'qwe', 'qwe', 'QWE', '87017515647'),
(2, 'alish', '25021998', 'alisher', '87016081165');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `prod`
--
ALTER TABLE `prod`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `prod`
--
ALTER TABLE `prod`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
