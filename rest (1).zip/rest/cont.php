<html>
	<head>
		<link rel="shortcut icon" href="img/значок-качества-пищи-ресторана-33714973.jpg" type="image/png">
		<meta charset="UTF-8">
		<title>Best choice</title>
		<link rel="stylesheet" type="text/css" href="base.css">
	</head>
	<body>
	<center>
			<?php
				include 'base.php';
			?>
			<div id="dow">
				<center>
					<h1 id="cuh">BEST-CHOICE</h1>
					<h2 style="color:black;font-size:50px;">Web-restaraunt Best choice present you big choices of Pizza/Sushi/Drinks/Desserts and Meat dishes</h2>
					<h2 style="color:black;font-size:35px;"> Контакты: </h2><h2 style="color:black;"> 8-701-608-11-65 </h2>
					<h2 style="color:black;font-size:35px;"> e-mail: </h2><h2 style="color:black;">best-dishes.kz_@gmail.com</h2>
					<br>
					<p style="color:black;font-size:45px;">Shop locates in the City-Mall 1st floor<br><img src='img/скачанные файлы.jpe  '>
				</center>
			</div>
			<div id="las">
			
			</div>
	</center>
	</body>
</html>