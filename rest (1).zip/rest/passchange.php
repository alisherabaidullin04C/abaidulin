<?php
	session_start();
	include 'connection.php';
	$pas1=$_POST['pas1'];
	$pas2=$_POST['pas2'];
	$query="SELECT * FROM users WHERE LOGIN='".$_SESSION['login']."'";
	$result=mysql_query($query);
	$a=mysql_fetch_array($result);
	if($pas1==$a[2]){
		$query="UPDATE `users` SET `PASSWORD`='".$pas2."' WHERE LOGIN='".$_SESSION['login']."'";
		$result=mysql_query($query);
		header("Location:profile.php");
	}
	else{
		echo "<h1 style='color:white; font-famile:segoe-script;'>PASSWORD hadn't been Changed</h1>";
		include 'profile.php';
		//header("Location:profile.php");
	}
?>